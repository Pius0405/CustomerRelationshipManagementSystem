document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
    document.querySelector('.welcome-user-animation').classList.add('show');
    }, 300); 
});